# SCanno Tutorial

### 1. Requirements:
- Python (v3.8.2)
- Scanpy (v1.81)
- Pandas (v1.3.4)
- Numpy (v1.20)
- Scikit_learn (v1.0.1)
- Tensorflow (v2.6.0)




